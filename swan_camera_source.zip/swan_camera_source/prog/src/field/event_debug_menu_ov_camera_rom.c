//=============================================================================
/**
 *
 *	@file		src\field\event_debug_menu_ov_pokewood.c
 *	@brief  �f�o�b�O���j���[�|�P�E�b�h�n�I�[�o�[���C�̈�
 *	@author	tamada GAMEFREAK inc.
 *	@date		2011.04.28
 *
 */
//=============================================================================
#ifdef  PM_DEBUG

//�V�X�e��
#include <gflib.h>
#include "system/gfl_use.h"
#include "gamesystem/game_data.h"
#include "gamesystem/game_event.h"
#include "arc_def.h"
#include "system/main.h" //for HEAPID_FIELDMAP
//#include "system/bmp_winframe.h"
#include "savedata/pokewood_savedata.h"
#include "font/font.naix"
#include "sound/pm_sndsys.h"

//�t�B�[���h
#include "fieldmap.h"
#include "field/zonedata.h"
#include "arc/fieldmap/zone_id.h"
#include "event_fieldmap_control.h"
#include "event_mapchange.h"
#include "field_fog.h"
#include "field_flash.h"
#include "field_light.h"
#include "field_camera.h"
#include "field_player.h"
#include "fldmmdl.h"

//#include "message.naix"
#include "debug_message.naix"
#include "msg/debug/msg_d_field.h"


//�A�v��
#include "savedata/battle_rec.h"
#include "savedata/pokewood_rec.h"
#include "app/pkwd_count.h"
#include "app/pkwd_book.h"
#include "app/pkwd_record_monitor.h"

//�f�o�b�O
#include "event_debug_menu.h"
#include "field_debug.h" 

#include "event_debug_local.h"
#include "event_debug_menu_ov_pokewood.h"

#include "pokewood_setup.h"
#include "battle/pokewood.h"
#include "event_debug_menu_ov_camera_rom.h"

//=============================================================================
//=============================================================================
#include "event_pokewood.h"

typedef struct _DEBUG_CAMERAROM_WORK DEBUG_CAMERAROM_WORK;

typedef BOOL(*CAMERAROM_FUNC)( DEBUG_CAMERAROM_WORK * );

//-----------------------------------------------------------------------------
//-----------------------------------------------------------------------------
struct _DEBUG_CAMERAROM_WORK
{
  int seq_no;
  HEAPID heapID;
  FLDSYSWIN * win;
  GFL_MSGDATA * msgData;
  GAMESYS_WORK *gmSys;
  GMEVENT *gmEvent;
  FIELDMAP_WORK *fieldWork;
  CAMERAROM_FUNC call_func;
  FLDMENUFUNC *menuFunc;
  u16         result;
  u16         sub_seq_no;
  u32         num;
  DEBUG_MENU_EVENT_WORK *d_work;
  u16 list_pos, cursor_pos;
  u8  ending; // �V�i���I�t���O����̃��[�h�ݒ�
  int light_no; // �ۑ����Ă������C�gNO
};

typedef DEBUG_CAMERAROM_WORK CAMERAROM_FUNC_WORK;

static GMEVENT_RESULT debugMenuCameraRomEvent( GMEVENT *event, int *seq, void *wk );

static BOOL debugMenuCallProc_CameraRomFunc1( CAMERAROM_FUNC_WORK * wk );
static BOOL debugMenuCallProc_CameraRomFunc2( CAMERAROM_FUNC_WORK * wk );
static BOOL debugMenuCallProc_CameraRomFunc3( CAMERAROM_FUNC_WORK * wk );
static BOOL debugMenuCallProc_CameraRomFunc4( CAMERAROM_FUNC_WORK * wk );
static BOOL debugMenuCallProc_CameraRomFunc5( CAMERAROM_FUNC_WORK * wk );
static BOOL debugMenuCallProc_CameraRomFunc6( CAMERAROM_FUNC_WORK * wk );

//-----------------------------------------------------------------------------
///���X�g ���j���[�w�b�_�[
//-----------------------------------------------------------------------------
static const FLDMENUFUNC_HEADER DebugCameraRomMenuHeader =
{
  1,    //���X�g���ڐ�
  7,    //�\���ő區�ڐ�
  0,    //���x���\���w���W
  13,   //���ڕ\���w���W
  0,    //�J�[�\���\���w���W
  0,    //�\���x���W
  1,    //�\�������F
  15,   //�\���w�i�F
  2,    //�\�������e�F
  0,    //�����Ԋu�w
  1,    //�����Ԋu�x
  FLDMENUFUNC_SKIP_LRKEY, //�y�[�W�X�L�b�v�^�C�v
  12,   //�����T�C�YX(�h�b�g
  12,   //�����T�C�YY(�h�b�g
  0,    //�\�����WX �L�����P��
  0,    //�\�����WY �L�����P��
  0,    //�\���T�C�YX �L�����P��
  0,    //�\���T�C�YY �L�����P��
};

//-----------------------------------------------------------------------------
///���j���[���X�g
//-----------------------------------------------------------------------------
static const DEBUG_MENU_LIST DebugCameraRomMenuList[] =
{
  { DEBUG_FIELD_CAMERA_STR_01, (void*)debugMenuCallProc_CameraRomFunc1, GFL_OVERLAY_BLANK_ID },
  { DEBUG_FIELD_CAMERA_STR_02, (void*)debugMenuCallProc_CameraRomFunc2, GFL_OVERLAY_BLANK_ID },
  { DEBUG_FIELD_CAMERA_STR_03, (void*)debugMenuCallProc_CameraRomFunc3, GFL_OVERLAY_BLANK_ID },
  { DEBUG_FIELD_CAMERA_STR_04, (void*)debugMenuCallProc_CameraRomFunc4, GFL_OVERLAY_BLANK_ID },
  { DEBUG_FIELD_CAMERA_STR_05, (void*)debugMenuCallProc_CameraRomFunc5, GFL_OVERLAY_BLANK_ID },
};

//-----------------------------------------------------------------------------
/// �f�o�b�O���j���[�������p�����[�^
//-----------------------------------------------------------------------------
static const DEBUG_MENU_INITIALIZER DebugMenuCameraRomInitializer = {
  NARC_debug_message_d_field_dat,
  NELEMS(DebugCameraRomMenuList),
  DebugCameraRomMenuList,
  &DebugCameraRomMenuHeader,
  1, 1, 20, 10,
  NULL,
  NULL
};

//=============================================================================
//=============================================================================

//-----------------------------------------------------------------------------
//-----------------------------------------------------------------------------
BOOL debugMenuCallProc_CameraRom( DEBUG_MENU_EVENT_WORK *wk )
{
  GAMESYS_WORK *gsys = wk->gmSys;
  GMEVENT *event = wk->gmEvent;
  HEAPID heapID = wk->heapID;
  FIELDMAP_WORK *fieldWork = wk->fieldWork;
  DEBUG_CAMERAROM_WORK *work;

  GMEVENT_Change( event, debugMenuCameraRomEvent, sizeof(DEBUG_CAMERAROM_WORK) );

  work = GMEVENT_GetEventWork( event );
  GFL_STD_MemClear( work, sizeof(DEBUG_CAMERAROM_WORK) );

  work->gmSys = gsys;
  work->gmEvent = event;
  work->heapID = heapID;
  work->fieldWork = fieldWork;

  
  return TRUE;
}

//-----------------------------------------------------------------------------
/**
 * �C�x���g�F�|�P�E�b�h�p�f�o�b�O���j���[
 * @param event GMEVENT
 * @param seq   �V�[�P���X
 * @param wk    event work
 * @retval  GMEVENT_RESULT
 */
//-----------------------------------------------------------------------------
static GMEVENT_RESULT debugMenuCameraRomEvent( GMEVENT *event, int *seq, void *wk )
{
  DEBUG_CAMERAROM_WORK *work = wk;
  u32 ret;

  switch( *seq ){
  case 0:
    work->menuFunc = DEBUGFLDMENU_Init( work->fieldWork, work->heapID, &DebugMenuCameraRomInitializer );
    (*seq)++;
    break;

  case 1:

    ret = FLDMENUFUNC_ProcMenu( work->menuFunc );
    switch( ret )
    {
    case FLDMENUFUNC_NULL:    // ���얳��
      break;

    case FLDMENUFUNC_CANCEL:  // �L�����Z��
      FLDMENUFUNC_DeleteMenu( work->menuFunc );
      return GMEVENT_RES_FINISH;

    default:
      {
        BOOL result;
        work->call_func = (CAMERAROM_FUNC)ret;
        FLDMENUFUNC_DeleteMenu( work->menuFunc );
        (*seq)++;
      }
    }
    break;

  case 2:
    if ( work->call_func( work ) == TRUE )
    {
      return GMEVENT_RES_CONTINUE;
    }
    else
    {
      return GMEVENT_RES_FINISH;
    }
    break;
  }

  return GMEVENT_RES_CONTINUE;
}



//=============================================================================
//=============================================================================
//-----------------------------------------------------------------------------
//-----------------------------------------------------------------------------
static BOOL callShowProc( CAMERAROM_FUNC_WORK * wk, PKWD_REC_POS rec_pos )
{
  LOAD_RESULT result;
  SAVE_CONTROL_WORK * sv = GAMEDATA_GetSaveControlWork( GAMESYSTEM_GetGameData( wk->gmSys ) );

//  if ( BattleRec_DataOccCheck( sv, HEAPID_FIELDMAP, &result, rec_pos ) == FALSE )
//  { //�Ή�����^��f�[�^�����݂��Ȃ��Ƃ��ɂ͂Ȃɂ������ɖ߂�
//    PMSND_PlaySE( SEQ_SE_BEEP );
//    return FALSE;
//  }
//  else
  {
    GMEVENT *event = wk->gmEvent;
    FIELDMAP_WORK *fieldWork = wk->fieldWork;
    GAMESYS_WORK  *gameSys  = wk->gmSys;
    GMEVENT *next_event;
    int rec_id = rec_pos;
    next_event = GMEVENT_CreateOverlayEventCall( gameSys,
        FS_OVERLAY_ID(notwifi_event_pokewood), POKEWOOD_EVENT_Show, (void*)&rec_id );
    GMEVENT_ChangeEvent( event, next_event );

    return TRUE;
  }
}


//-----------------------------------------------------------------------------
//-----------------------------------------------------------------------------
static BOOL debugMenuCallProc_CameraRomFunc1( CAMERAROM_FUNC_WORK * wk )
{
  FIELD_DEBUG_SetPerspectiveFlag();
  OS_Printf("�J�����؂�ւ��Ăяo��:%d\n", FIELD_DEBUG_GetPerspectiveFlag());

  FIELDMAP_SwitchCamera( wk->fieldWork, FIELD_DEBUG_GetPerspectiveFlag() );
  return FALSE;
}

//-----------------------------------------------------------------------------
//-----------------------------------------------------------------------------
static BOOL debugMenuCallProc_CameraRomFunc2( CAMERAROM_FUNC_WORK * wk )
{
  FIELD_LIGHT *light = FIELDMAP_GetFieldLight( wk->fieldWork );
  OS_Printf("���邳�؂�ւ��Ăяo��\n");
  FIELD_DEBUG_SwitchLight();
  if(FIELD_DEBUG_GetLight()==0){
    OS_Printf("lightno=%d ���A\n", FIELD_DEBUG_GetLightNo());
    FIELD_LIGHT_Change( light, FIELD_DEBUG_GetLightNo() );
  }else{
    FIELD_DEBUG_ReserveLightNo( FIELD_LIGHT_GetLightNo( light ) );
    FIELD_LIGHT_Change( light, 1 );
    OS_Printf("lightno=%d �ۑ�\n", FIELD_DEBUG_GetLightNo());
  }
  return FALSE;
}

//-----------------------------------------------------------------------------
//-----------------------------------------------------------------------------
static BOOL debugMenuCallProc_CameraRomFunc3( CAMERAROM_FUNC_WORK * wk )
{
  OS_Printf("�t�H�O�؂�ւ��Ăяo��\n");
  FIELD_DEBUG_SetNoFog();
  // 13,14�ԓ��H�Ŋm�F

  if( FIELD_DEBUG_GetNoFog()==TRUE ){
    FIELD_FOG_SetFlag( FIELDMAP_GetFieldFog( wk->fieldWork ), FALSE );
  }else{
    FIELD_FOG_SetFlag( FIELDMAP_GetFieldFog( wk->fieldWork ), TRUE );
  }
  return FALSE;
}

//-----------------------------------------------------------------------------
//-----------------------------------------------------------------------------
static BOOL debugMenuCallProc_CameraRomFunc4( CAMERAROM_FUNC_WORK * wk )
{
  FIELDSKILL_MAPEFF* cp_wk = FIELDMAP_GetFieldSkillMapEffect( wk->fieldWork );
  FIELD_FLASH *field_flash = FIELDSKILL_MAPEFF_GetFlash( cp_wk );
  // �t�L���Z�̓��A�Ŋm�F
  OS_Printf("�t���b�V���}�X�N�Ăяo��\n");
  FIELD_DEBUG_SetNoFlashMask();
  
  if(FIELD_DEBUG_GetNoFlashMask()==0){
    FIELD_FLASH_Control( field_flash, FIELD_FLASH_REQ_ON_NEAR );
  }else{
//    FIELD_FLASH_Control( field_flash, FIELD_FLASH_REQ_OFF );
    FIELD_FLASH_Control( field_flash, FIELD_FLASH_REQ_ON_FAR );

  }
  return FALSE;
}

//-----------------------------------------------------------------------------
//-----------------------------------------------------------------------------
static BOOL debugMenuCallProc_CameraRomFunc5( CAMERAROM_FUNC_WORK * wk )
{
  const FIELD_PLAYER *cp_player  = FIELDMAP_GetFieldPlayer( wk->fieldWork );
  MMDL *mmdl = FIELD_PLAYER_GetMMdl( cp_player );
  OS_Printf("���������Ăяo��\n");

  FIELD_DEBUG_SwitchNoHeightGet();

  MMDL_SetStatusBitHeightGetOFF( mmdl, FIELD_DEBUG_GetNoHeightGet() );
  return FALSE;
}

//-----------------------------------------------------------------------------
//-----------------------------------------------------------------------------
static BOOL debugMenuCallProc_CameraRomFunc6( CAMERAROM_FUNC_WORK * wk )
{
  OS_Printf("�f�t�H���g�J�����Ăяo��\n");
  FIELD_DEBUG_SetPerspectiveFlag();
  return FALSE;
}



#endif  //  PM_DEBUG

